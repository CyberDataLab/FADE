from django.apps import AppConfig


class ActionExecutionConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'action_execution'
