export interface UserLogin{
    username: String;
    password: String;
}