import { Component } from '@angular/core';

@Component({
  selector: 'app-anomaly-detector',
  standalone: true,
  imports: [],
  templateUrl: './anomaly-detector.component.html',
  styleUrl: './anomaly-detector.component.css'
})
export class AnomalyDetectorComponent {

}
