import { Component } from '@angular/core';

@Component({
  selector: 'app-xai',
  standalone: true,
  imports: [],
  templateUrl: './xai.component.html',
  styleUrl: './xai.component.css'
})
export class XaiComponent {

}
